Resurrection — The Summer We Never Finished: playtest folder (build b78e03b)

1. Open START-HERE.html (double-click) and read it. It takes two minutes.
2. Double-click Resurrection-V5-Playtest.html to play. No installation, no internet.
3. Afterwards open feedback-form.html, and give the downloaded files to the person who gave you this folder.

The game keeps a play record inside your browser only. It is never sent anywhere. You can delete it in the pause menu.

---

请先双击打开 START-HERE.html（两分钟）。然后双击 Resurrection-V5-Playtest.html 开始游戏，无需安装也不需要联网。
玩完后打开 feedback-form.html，把下载的文件交给给你这个文件夹的人。
游玩记录只保存在你的浏览器里，不会被发送到任何地方，可在暂停菜单中删除。
